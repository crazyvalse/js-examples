function execute () {
  var h1 = document.createElement('h1')
  h1.innerText = '这里是02.js的execute方法'
  document.body.appendChild(h1)
}
