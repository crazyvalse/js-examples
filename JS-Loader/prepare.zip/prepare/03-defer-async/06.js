let now = Date.now()
while (Date.now() - now < 2000){}
console.info('-6')
